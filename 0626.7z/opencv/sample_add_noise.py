import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('opencv_logo.png')
noised = img + np.random.normal(0, 1, img.shape[0] * img.shape[1] * img.shape[2]).reshape(img.shape)

plt.subplot(121),plt.imshow(img),plt.title('Original')
plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(noised),plt.title('Noised')
plt.xticks([]), plt.yticks([])
plt.show()