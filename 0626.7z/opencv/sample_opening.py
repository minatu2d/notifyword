import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('moji.png',0)
ret, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV)
noised_idx = np.random.randint(low=0, high=img.shape[0] * img.shape[1], size=40000)
noised = np.zeros(img.shape[0] * img.shape[1])
noised[noised_idx] =+ 127
img = img + noised.reshape(img.shape)

print(img.shape)
kernel = np.ones((5,5),np.uint8)
#erosion = cv2.erode(img,kernel,iterations = 1)
#dilation = cv2.dilate(img,kernel,iterations = 1)
opening = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)

plt.subplot(121),plt.imshow(img, cmap='gray'),plt.title('Original')
plt.xticks([]), plt.yticks([])
plt.subplot(122),plt.imshow(opening, cmap='gray'),plt.title('Opening')
plt.xticks([]), plt.yticks([])
plt.show()