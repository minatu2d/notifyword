import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('opencv_logo.png')
print(img.shape)
lower_reso = cv2.pyrDown(img)
print(lower_reso.shape)
lower_reso_2 = cv2.pyrDown(lower_reso)
print(lower_reso_2.shape)
higher_reso2 = cv2.pyrUp(lower_reso_2)
print(higher_reso2.shape)

plt.subplot(1,3,1),plt.imshow(img,cmap = 'gray')
plt.title('Org'), plt.xticks([]), plt.yticks([])
plt.subplot(1,3,2),plt.imshow(lower_reso_2,cmap = 'gray')
plt.title('Pyramid Down'), plt.xticks([]), plt.yticks([])
plt.subplot(1,3,3),plt.imshow(higher_reso2,cmap = 'gray')
plt.title('Pyramid Up'), plt.xticks([]), plt.yticks([])

plt.show()