import cv2
import numpy as np
from matplotlib import pyplot as plt

from os import listdir
from os.path import isfile, join
mypath="."
onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]
count = 0
for i in range(len(onlyfiles)):
	if ("png" in onlyfiles[i]):
		img = cv2.imread(onlyfiles[i],0)
		edges = cv2.Canny(img,100,200)

		plt.subplot(9,2,count * 2 + 1),plt.imshow(img,cmap = 'gray')
		plt.title('Original Image'), plt.xticks([]), plt.yticks([])
		plt.subplot(9,2,count * 2 + 2),plt.imshow(edges,cmap = 'gray')
		plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
		count = count + 1

plt.show()