import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('sample_image.png',0)
ret,thresh = cv2.threshold(img,127,255,0)
_,contours,_ = cv2.findContours(thresh, 1, 2)

cnt = contours[2]
print("Contour :{0}".format(cnt))
area = cv2.contourArea(cnt)
print("Area of the contour :{0}",format(area))

plt.subplot(1,2,1),plt.imshow(thresh,cmap = 'gray')
plt.title('Origin'), plt.xticks([]), plt.yticks([])

plt.show()