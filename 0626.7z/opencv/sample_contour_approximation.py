import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('sample_image.png',0)
ret,thresh = cv2.threshold(img,127,255,0)
_,contours,_ = cv2.findContours(thresh, 1, 2)

cnt = contours[2]
print("Contour :{0}".format(cnt))
#area = cv2.contourArea(cnt)
#perimeter = cv2.arcLength(cnt,True)
epsilon = 0.1 * cv2.arcLength(cnt,True)
approx1 = cv2.approxPolyDP(cnt,epsilon,True)
epsilon = 0.01 * cv2.arcLength(cnt,True)
approx2 = cv2.approxPolyDP(cnt,epsilon,True)
#print("Contour Approximation :{0}",format(approx))

cv2.polylines(img, [approx1], True, (0,0,255))
cv2.imshow("Contours", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
